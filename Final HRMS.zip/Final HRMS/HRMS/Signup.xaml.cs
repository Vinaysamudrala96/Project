﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using HRMS.Entity;
using HRMS.Exceptions;
using HRMS.BL;


namespace HRMS
{
    /// <summary>
    /// Interaction logic for Signup.xaml
    /// </summary>
    public partial class Signup : Window
    {
        public Signup()
        {
            InitializeComponent();
        }

        private void button_SignUp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Users user = new Users();
                UserRoles role = new UserRoles();
                user.UserId = Convert.ToInt32(textBox_AdminUsers_ID.Text);
                user.UserName = textBox_UserName.Text;
                user.Password = passwordBox.Password.ToString();
                // MessageBox.Show(user.Password);
                user.FirstName = textBox_FirstName.Text;
                user.LastName = textBox_LastName.Text;

                role.UserId = user.UserId;
                role.RoleId = Convert.ToInt32(cmb_role.SelectedValue.ToString());



                int rowsAffected = UserValidation.AddClerk_BLL(user, role);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("User  Details Added Successfully");
                }
                else
                {
                    MessageBox.Show("Error!!! User Details not Added");
                }
            }
            catch (HRMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            textBox_AdminUsers_ID.Text = UserValidation.AutoGenUserId_BL().ToString();
            DataTable dtRole = UserValidation.LoadUserRoles_BLL();
            if (dtRole.Rows.Count >= 0)
            {
                cmb_role.ItemsSource = dtRole.DefaultView;

                cmb_role.DisplayMemberPath = "Role_Name";
                cmb_role.SelectedValuePath = "Role_Id";

            }

        }
    }
}
